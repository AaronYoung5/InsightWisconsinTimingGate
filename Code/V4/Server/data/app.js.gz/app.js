// Constraints (settings) for the camera
var track, frame, intervalId;
var constraints = {video: {facingMode: "environment"}, audio: false};
var lastSum = 0;
var firstTimes = 0;

// Define constants for the elements created
const cameraView = document.querySelector("#camera-view"),
    cameraOutput = document.querySelector("#camera-output"),
    cameraSensor = document.querySelector("#camera-sensor"),
    cameraTrigger = document.querySelector("#camera-trigger"),
    cameraFlipper = document.querySelector("#camera-flipper"),
    cameraStopper = document.querySelector("#camera-stopper");

// Accesses the camera and streams video to the camera-view element
// Uses getUserMedia method using the constraints created earlier
// Will used .catch to make sure an error is reported if camera doesn't work
function cameraStart() {
    navigator.mediaDevices
        .getUserMedia(constraints)
        .then(function(stream) {
            track = stream.getTracks()[0];
            cameraView.srcObject = stream;
        })
        .catch(function(error) {
            console.error("Oops. Something is broken.", error);
        })
    analyzeImages();
}

// Function that grabs a frame from the stream when button is pressed
cameraTrigger.onclick = function() {
    cameraSensor.width = cameraView.videoWidth;
    cameraSensor.height = cameraView.videoHeight;
   
    context = cameraSensor.getContext("2d");


    context.drawImage(cameraView, 0, 0);
    var imageData = context.getImageData(0,0,cameraSensor.width,cameraSensor.height);

    sum = analyzeImage(imageData.data);

    console.log(sum)
    cameraOutput.src = cameraSensor.toDataURL("image/webp");
    cameraOutput.classList.add("taken");
}

// Function that inverses colors of image
function analyzeImage() {
    function analyzeData(data) {
        var totalSum = 0;
        for (var i = 0; i < data.length; i+=4) {
            totalSum += data[i] + data[i+1] + data[i+2];
        }
        return totalSum;
    }
    try {
        cameraSensor.width = cameraView.videoWidth;
        cameraSensor.height = cameraView.videoHeight;
        context = cameraSensor.getContext("2d");
        context.drawImage(cameraView, 0, 0);
        var imageData = context.getImageData(0,0,cameraSensor.width,cameraSensor.height);
        sum = analyzeData(imageData.data);
        diff = Math.abs(sum - lastSum);
    }
    catch (e) {
        return;
    }
    if(firstTimes < 2) {
        firstTimes += 1;
    }
    else if(diff > 70000000) {
        try {
            console.log(diff);
            document.getElementById("camera-trigger").innerHTML = diff;
            track.stop();
            toggleDisplay("watch");
            if(el.time.innerHTML != "") {
                el.stop.onclick();
            }
        }
        catch (e) {
            console.error("ERRORERRORERRORERROR",e);
        }
    }
    lastSum = sum;
}

// Function that flips camera direction when flipper is clicked
cameraFlipper.onclick = function() {
    console.log(track)
    console.log(track.getCapabilities());
    if (constraints.video.facingMode == "user") {
        constraints.video.facingMode = "environment";
        document.getElementById("camera-view").style.transform = "scaleX(1)";
        document.getElementById("camera-sensor").style.transform = "scaleX(1)";
        document.getElementById("camera-output").style.transform = "scaleX(1)";
    }
    else {
        constraints.video.facingMode = "user";
        document.getElementById("camera-view").style.transform = "scaleX(-1)";
        document.getElementById("camera-sensor").style.transform = "scaleX(-1)";
        document.getElementById("camera-output").style.transform = "scaleX(-1)";
    }
    cameraStart();
}

cameraStopper.onclick = function() {
    if (track != null) {
        if(track.enabled) {
            track.stop();
            track.enabled = false;
            window.clearInterval(intervalId);
            document.getElementById("camera-stopper").src = 'video-play.png';
            toggleDisplay("watch");
        }
        else {
            cameraStart();
            document.getElementById("camera-stopper").src = 'video-pause.png';
        }
    }
    else {
        console.log("Cannot stop video because it is not working.");
    }
}

function analyzeImages() {
    intervalId = window.setInterval(function() {
        analyzeImage();
    }, 1000/30)
}

function main() {
    if(document.getElementById("video-div").display == "block") {
       cameraStart(); 
    }
}

// Initiates cameraStart function when window is finished loading
window.addEventListener("load", main, false)
